package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.dto.UserDTO;
import com.bridgeport.lbsservice.dto.request.UserRequest;
import com.bridgeport.lbsservice.dto.response.UserResponse;
import com.bridgeport.lbsservice.model.UserRole;
import com.bridgeport.lbsservice.repository.custom.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
public class UserController {

    private UserRepository userRepository;

    @GetMapping("/users")
    public ResponseEntity<List<UserResponse>> users(Authentication authentication) {
        List<UserDTO> userDTOs = userRepository.findAllExceptWithGivenUsername(authentication.getName());
        List<UserResponse> userResponses = userDTOs.stream().map(ud -> UserResponse.builder()
                        .username(ud.getUsername())
                        .role(UserRole.values()[ud.getRoleId()].getLabel())
                        .firstName(ud.getFirstName())
                        .middleName(ud.getMiddleName())
                        .lastName(ud.getLastName())
                        .gender(ud.getGender())
                        .ssn(ud.getSsn())
                        .email(ud.getEmail())
                        .phone(ud.getPhone())
                        .country(ud.getCountry())
                        .state(ud.getState())
                        .city(ud.getCity())
                        .street(ud.getStreet())
                        .zip(ud.getZip())
                        .build())
                .toList();
        return new ResponseEntity<>(userResponses, HttpStatus.OK);
    }

    @PostMapping("/user")
    @Transactional(propagation = Propagation.REQUIRED)
    public ResponseEntity<Void> createUser(@RequestBody UserRequest userRequest) {
        userRepository.save(userRequest);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
