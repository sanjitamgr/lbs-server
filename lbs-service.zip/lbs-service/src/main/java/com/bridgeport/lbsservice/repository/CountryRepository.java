package com.bridgeport.lbsservice.repository;

import com.bridgeport.lbsservice.entity.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CountryRepository extends JpaRepository<Country, Long> {

    @Query(value = "SELECT * FROM country ORDER BY name ASC", nativeQuery = true)
    List<Country> getCountries();
}
