package com.bridgeport.lbsservice.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuctionLaptopRequest {

    private String title;
    private String description;
    private Integer ram;
    private String cpu;
    private BigDecimal initialPrice;
    private Long brandId;
    private Long operatingSystemId;
}
