package com.bridgeport.lbsservice.repository.custom;

import com.bridgeport.lbsservice.dto.response.TransactionResponse;
import com.bridgeport.lbsservice.model.AuctionStatus;
import com.bridgeport.lbsservice.util.Util;
import lombok.AllArgsConstructor;
import net.bytebuddy.utility.RandomString;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor
public class TransactionRepository {

    private static RowMapper<TransactionResponse> transactionResponseRowMapper = (rs, rowNum) -> TransactionResponse.builder()
            .title(rs.getString("title"))
            .seller(Util.getDisplayName(rs.getString("sFName"), rs.getString("sMName"), rs.getString("sLName")))
            .buyer(Util.getDisplayName(rs.getString("bFName"), rs.getString("bMName"), rs.getString("bLName")))
            .shippingTrackNumber(rs.getString("shipping_track_number"))
            .initialPrice(rs.getBigDecimal("initial_price"))
            .soldPrice(rs.getBigDecimal("price"))
            .date(rs.getDate("time"))
            .build();
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void save(Long bidId) {
        String query = "INSERT INTO" +
                " transaction (time, shipping_track_number, bid_id)" +
                " VALUES (:time, :shippingTrackNumber, :bidId)";
        Map<String, Object> params = new HashMap<>();
        params.put("time", new Date());
        params.put("shippingTrackNumber", RandomString.make(24).toUpperCase());
        params.put("bidId", bidId);
        jdbcTemplate.update(query, params);
        query = "UPDATE auction_laptop SET status_id = :statusId" +
                " WHERE id IN (" +
                "   SELECT auction_laptop_id FROM bid WHERE id = :bidId" +
                " )";
        params = new HashMap<>();
        params.put("statusId", AuctionStatus.SOLD.ordinal());
        params.put("bidId", bidId);
        jdbcTemplate.update(query, params);
    }

    public List<TransactionResponse> findBySellerOrBuyerId(Long id) {
        String query = "SELECT t.*, b.price, al.title, al.initial_price, seller.*, buyer.*" +
                " FROM transaction t" +
                " LEFT JOIN bid b ON b.id = t.bid_id" +
                " LEFT JOIN auction_laptop al ON al.id = b.auction_laptop_id" +
                " LEFT JOIN (SELECT u.id AS sId, u.first_name AS sFName, u.middle_name AS sMName, u.last_name AS sLName FROM user u) seller ON seller.sId = al.seller_id" +
                " LEFT JOIN (SELECT u.id AS bId, u.first_name AS bFName, u.middle_name AS bMName, u.last_name AS bLName FROM user u) buyer ON buyer.bId = b.bidder_id" +
                " WHERE seller.sId = :id OR buyer.bId = :id" +
                " ORDER BY t.time DESC";
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        return jdbcTemplate.query(query, params, transactionResponseRowMapper);
    }

    public List<TransactionResponse> findAll() {
        String query = "SELECT t.*, b.price, al.title, al.initial_price, seller.*, buyer.*" +
                " FROM transaction t" +
                " LEFT JOIN bid b ON b.id = t.bid_id" +
                " LEFT JOIN auction_laptop al ON al.id = b.auction_laptop_id" +
                " LEFT JOIN (SELECT u.id AS sId, u.first_name AS sFName, u.middle_name AS sMName, u.last_name AS sLName FROM user u) seller ON seller.sId = al.seller_id" +
                " LEFT JOIN (SELECT u.id AS bId, u.first_name AS bFName, u.middle_name AS bMName, u.last_name AS bLName FROM user u) buyer ON buyer.bId = b.bidder_id" +
                " ORDER BY t.time DESC";
        Map<String, Object> params = new HashMap<>();
        return jdbcTemplate.query(query, params, transactionResponseRowMapper);
    }
}
