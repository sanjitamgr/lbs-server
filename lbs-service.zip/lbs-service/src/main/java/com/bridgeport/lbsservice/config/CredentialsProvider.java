package com.bridgeport.lbsservice.config;

import com.bridgeport.lbsservice.model.UserRole;
import lombok.Setter;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

@Component
@RequestScope
public class CredentialsProvider {

    @Setter
    private String token;

    private JwtTokenService jwtTokenService;

    public CredentialsProvider(JwtTokenService jwtTokenService) {
        this.jwtTokenService = jwtTokenService;
    }

    public Long getUserId() {
        return jwtTokenService.getClaimFromToken(token, claims -> claims.get("userId", Long.class));
    }

    public UserRole getUserRole() {
        return jwtTokenService.getClaimFromToken(token, claims -> UserRole.valueOf(claims.get("userRole", String.class)));
    }
}
