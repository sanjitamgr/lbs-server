package com.bridgeport.lbsservice.repository.custom;

import com.bridgeport.lbsservice.dto.request.BidRequest;
import com.bridgeport.lbsservice.dto.response.BidResponse;
import com.bridgeport.lbsservice.util.Util;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor
public class BidRepository {

    private static RowMapper<BidResponse> bidResponseRowMapper = (rs, rowNum) -> BidResponse.builder()
            .id(rs.getLong("id"))
            .price(rs.getBigDecimal("price"))
            .date(rs.getDate("time"))
            .bidder(Util.getDisplayName(rs.getString("first_name"), rs.getString("middle_name"), rs.getString("last_name")))
            .build();
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void save(BidRequest bidRequest, Long bidderId) {
        String query = "INSERT INTO" +
                " bid (price, time, auction_laptop_id, bidder_id)" +
                " VALUES (:price, :time, :auctionLaptopId, :bidderId)";
        Map<String, Object> params = new HashMap<>();
        params.put("price", bidRequest.getPrice());
        params.put("time", new Date());
        params.put("auctionLaptopId", bidRequest.getAuctionLaptopId());
        params.put("bidderId", bidderId);
        jdbcTemplate.update(query, params);
    }

    public List<BidResponse> findAll(Long auctionLaptopId) {
        String query = "SELECT b.*, u.first_name, u.middle_name, u.last_name" +
                " FROM bid b" +
                " LEFT JOIN user u ON u.id = b.bidder_id" +
                " WHERE b.auction_laptop_id = :auctionLaptopId" +
                " ORDER BY price DESC";
        Map<String, Object> params = new HashMap<>();
        params.put("auctionLaptopId", auctionLaptopId);
        return jdbcTemplate.query(query, params, bidResponseRowMapper);
    }
}
