package com.bridgeport.lbsservice.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuctionLaptopResponse {

    private Long id;
    private String title;
    private String description;
    private Integer ram;
    private String cpu;
    private BigDecimal initialPrice;
    private String brand;
    private String operatingSystem;
    private String status;
    private String statusEnumName;
    private Long sellerId;
    private String seller;
}
