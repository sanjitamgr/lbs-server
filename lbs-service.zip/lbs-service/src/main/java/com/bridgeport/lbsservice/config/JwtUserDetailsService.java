package com.bridgeport.lbsservice.config;

import com.bridgeport.lbsservice.dto.UserDTO;
import com.bridgeport.lbsservice.model.UserRole;
import com.bridgeport.lbsservice.repository.custom.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class JwtUserDetailsService implements UserDetailsService {

    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            UserDTO userDTO = userRepository.getByUsername(username);
            if (userDTO != null) {
                return User.builder()
                        .username(userDTO.getUsername())
                        .password(userDTO.getPassword())
                        .roles(UserRole.values()[userDTO.getRoleId()].name())
                        .build();
            } else {
                throw new UsernameNotFoundException("User not found with username: " + username);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}
