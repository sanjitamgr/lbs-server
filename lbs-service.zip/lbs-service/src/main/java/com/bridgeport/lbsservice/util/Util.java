package com.bridgeport.lbsservice.util;

import org.springframework.util.StringUtils;

public class Util {

    public static String getDisplayName(String firstName, String middleName, String lastName) {
        if (StringUtils.hasText(firstName) && StringUtils.hasText(middleName) && StringUtils.hasText(lastName)) {
            return lastName + ", " + firstName + " " + middleName;
        } else if (StringUtils.hasText(firstName) && StringUtils.hasText(lastName)) {
            return lastName + ", " + firstName;
        }
        return "";
    }
}
