package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.config.CredentialsProvider;
import com.bridgeport.lbsservice.dto.response.DashboardResponse;
import com.bridgeport.lbsservice.model.UserRole;
import com.bridgeport.lbsservice.repository.custom.DashboardRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class DashboardController {

    private CredentialsProvider credentialsProvider;
    private DashboardRepository dashboardRepository;

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardResponse> dashboard() {
        if (credentialsProvider.getUserRole() != UserRole.ADMIN) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(dashboardRepository.getDashboardResponse(), HttpStatus.OK);
    }
}
