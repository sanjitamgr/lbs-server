package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.config.CredentialsProvider;
import com.bridgeport.lbsservice.dto.request.MessageRequest;
import com.bridgeport.lbsservice.dto.response.MessageResponse;
import com.bridgeport.lbsservice.repository.custom.MessageRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class MessageController {

    private CredentialsProvider credentialsProvider;
    private MessageRepository messageRepository;

    @PostMapping("/message")
    public ResponseEntity<Void> createBid(@RequestBody MessageRequest messageRequest) {
        messageRepository.save(messageRequest, credentialsProvider.getUserId());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/messages/{itemId}")
    public ResponseEntity<List<MessageResponse>> bids(@PathVariable("itemId") Long itemId) {
        List<MessageResponse> messageResponses = messageRepository.findByItemId(itemId);
        return new ResponseEntity<>(messageResponses, HttpStatus.OK);
    }
}
