package com.bridgeport.lbsservice.entity;

import com.bridgeport.lbsservice.model.MessageStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "message")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "msg")
    private String msg;

    @Column(name = "sent_timestamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sentTimestamp;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status_id")
    private MessageStatus status;

    @ManyToOne()
    @JoinColumn(name = "item_id")
    private AuctionLaptop item;

    @ManyToOne()
    @JoinColumn(name = "sender_id")
    private User sender;
}
