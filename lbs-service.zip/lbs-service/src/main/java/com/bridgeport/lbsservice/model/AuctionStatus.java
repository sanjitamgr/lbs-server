package com.bridgeport.lbsservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum AuctionStatus {

    BID_ONGOING("Bid Ongoing"), SOLD("Sold");

    @Getter
    private String label;
}
