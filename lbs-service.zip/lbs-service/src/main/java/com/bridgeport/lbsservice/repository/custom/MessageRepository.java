package com.bridgeport.lbsservice.repository.custom;

import com.bridgeport.lbsservice.dto.request.MessageRequest;
import com.bridgeport.lbsservice.dto.response.MessageResponse;
import com.bridgeport.lbsservice.model.MessageStatus;
import com.bridgeport.lbsservice.util.Util;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor
public class MessageRepository {

    private static RowMapper<MessageResponse> transactionResponseRowMapper = (rs, rowNum) -> MessageResponse.builder()
            .msg(rs.getString("msg"))
            .sender(Util.getDisplayName(rs.getString("first_name"), rs.getString("middle_name"), rs.getString("last_name")))
            .date(rs.getDate("sent_timestamp"))
            .build();
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void save(MessageRequest messageRequest, Long senderId) {
        String query = "INSERT INTO" +
                " message (msg, sent_timestamp, status_id, item_id, sender_id)" +
                " VALUES (:msg, :sentTimestamp, :statusId, :itemId, :senderId)";
        Map<String, Object> params = new HashMap<>();
        params.put("msg", messageRequest.getMsg());
        params.put("sentTimestamp", new Date());
        params.put("statusId", MessageStatus.UNSEEN.ordinal());
        params.put("itemId", messageRequest.getItemId());
        params.put("senderId", senderId);
        jdbcTemplate.update(query, params);
    }

    public List<MessageResponse> findByItemId(Long itemId) {
        String query = "SELECT *" +
                " FROM message m" +
                " LEFT JOIN user u ON u.id = m.sender_id" +
                " WHERE m.item_id = :itemId" +
                " ORDER BY m.sent_timestamp DESC";
        Map<String, Object> params = new HashMap<>();
        params.put("itemId", itemId);
        return jdbcTemplate.query(query, params, transactionResponseRowMapper);
    }
}
