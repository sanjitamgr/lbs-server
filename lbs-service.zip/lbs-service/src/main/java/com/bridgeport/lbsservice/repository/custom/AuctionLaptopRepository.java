package com.bridgeport.lbsservice.repository.custom;

import com.bridgeport.lbsservice.dto.request.AuctionLaptopRequest;
import com.bridgeport.lbsservice.dto.response.AuctionLaptopResponse;
import com.bridgeport.lbsservice.model.AuctionStatus;
import com.bridgeport.lbsservice.util.Util;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor
public class AuctionLaptopRepository {

    private static RowMapper<AuctionLaptopResponse> auctionLaptopResponseRowMapper = (rs, rowNum) -> AuctionLaptopResponse.builder()
            .id(rs.getLong("id"))
            .title(rs.getString("title"))
            .description(rs.getString("description"))
            .ram(rs.getInt("ram"))
            .cpu(rs.getString("cpu"))
            .initialPrice(rs.getBigDecimal("initial_price"))
            .brand(rs.getString("brand"))
            .operatingSystem(rs.getString("os_name"))
            .status(AuctionStatus.values()[rs.getInt("status_id")].getLabel())
            .statusEnumName(AuctionStatus.values()[rs.getInt("status_id")].name())
            .sellerId(rs.getLong("seller_id"))
            .seller(Util.getDisplayName(rs.getString("first_name"), rs.getString("middle_name"), rs.getString("last_name")))
            .build();
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void save(AuctionLaptopRequest auctionLaptopRequest, Long sellerId) {
        String query = "INSERT INTO" +
                " auction_laptop (title, description, ram, cpu, initial_price, created_timestamp, brand_id, os_id, seller_id, status_id)" +
                " VALUES (:title, :description, :ram, :cpu, :initialPrice, :createdTimestamp, :brandId, :osId, :sellerId, :statusId)";
        Map<String, Object> params = new HashMap<>();
        params.put("title", auctionLaptopRequest.getTitle());
        params.put("description", auctionLaptopRequest.getDescription());
        params.put("ram", auctionLaptopRequest.getRam());
        params.put("cpu", auctionLaptopRequest.getCpu());
        params.put("initialPrice", auctionLaptopRequest.getInitialPrice());
        params.put("createdTimestamp", new Date());
        params.put("brandId", auctionLaptopRequest.getBrandId());
        params.put("osId", auctionLaptopRequest.getOperatingSystemId());
        params.put("sellerId", sellerId);
        params.put("statusId", AuctionStatus.BID_ONGOING.ordinal());
        jdbcTemplate.update(query, params);
    }

    // Bid Page - See Bids
    public AuctionLaptopResponse findById(Long id) {
        String query = "SELECT al.*, b.name AS brand, os.name AS os_name, u.first_name AS first_name, u.middle_name AS middle_name, u.last_name AS last_name" +
                " FROM auction_laptop al" +
                " LEFT JOIN brand b ON b.id = al.brand_id" +
                " LEFT JOIN operating_system os ON os.id = al.os_id" +
                " LEFT JOIN user u ON u.id = al.seller_id" +
                " WHERE al.id = :id" +
                " ORDER BY created_timestamp DESC";
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        List<AuctionLaptopResponse> auctionLaptopResponses = jdbcTemplate.query(query, params, auctionLaptopResponseRowMapper);
        return !auctionLaptopResponses.isEmpty() ? auctionLaptopResponses.get(0) : null;
    }

    // Home / Bidding Dashboard
    public List<AuctionLaptopResponse> findAllExceptSold() {
        String query = "SELECT al.*, b.name AS brand, os.name AS os_name, u.first_name AS first_name, u.middle_name AS middle_name, u.last_name AS last_name" +
                " FROM auction_laptop al" +
                " LEFT JOIN brand b ON b.id = al.brand_id" +
                " LEFT JOIN operating_system os ON os.id = al.os_id" +
                " LEFT JOIN user u ON u.id = al.seller_id" +
                " WHERE al.status_id <> :statusId" +
                " ORDER BY created_timestamp DESC";
        Map<String, Object> params = new HashMap<>();
        params.put("statusId", AuctionStatus.SOLD.ordinal());
        return jdbcTemplate.query(query, params, auctionLaptopResponseRowMapper);
    }

    // My Items
    public List<AuctionLaptopResponse> findAllForGivenUserId(Long userId) {
        String query = "SELECT al.*, b.name AS brand, os.name AS os_name, u.first_name AS first_name, u.middle_name AS middle_name, u.last_name AS last_name" +
                " FROM auction_laptop al" +
                " LEFT JOIN brand b ON b.id = al.brand_id" +
                " LEFT JOIN operating_system os ON os.id = al.os_id" +
                " LEFT JOIN user u ON u.id = al.seller_id" +
                " WHERE al.seller_id = :sellerId" +
                " ORDER BY created_timestamp DESC";
        Map<String, Object> params = new HashMap<>();
        params.put("sellerId", userId);
        return jdbcTemplate.query(query, params, auctionLaptopResponseRowMapper);
    }
}
