package com.bridgeport.lbsservice.entity;

import com.bridgeport.lbsservice.model.AuctionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "auction_laptop")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuctionLaptop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "ram")
    private Integer ram;

    @Column(name = "cpu")
    private String cpu;

    @Column(name = "initial_price")
    private BigDecimal initialPrice;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_timestamp")
    private Date createdTimestamp;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status_id")
    private AuctionStatus status;

    @ManyToOne
    @JoinColumn(name = "brand_id")
    private Brand brand;

    @ManyToOne
    @JoinColumn(name = "os_id")
    private OperatingSystem operatingSystem;

    @ManyToOne()
    @JoinColumn(name = "seller_id")
    private User seller;
}
