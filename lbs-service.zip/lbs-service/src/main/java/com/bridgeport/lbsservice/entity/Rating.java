package com.bridgeport.lbsservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "rating")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "value")
    private Byte value;

    @Column(name = "comment")
    private String comment;

    @Column(name = "is_bidder")
    private Boolean isBidder;

    @ManyToOne
    @JoinColumn(name = "transaction_id")
    private Transaction transaction;
}
