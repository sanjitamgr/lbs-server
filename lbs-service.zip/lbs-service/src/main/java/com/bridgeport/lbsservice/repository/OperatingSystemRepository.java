package com.bridgeport.lbsservice.repository;

import com.bridgeport.lbsservice.entity.OperatingSystem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface OperatingSystemRepository extends JpaRepository<OperatingSystem, Long> {

    @Query(value = "SELECT * FROM operating_system ORDER BY name ASC", nativeQuery = true)
    List<OperatingSystem> getOperatingSystems();
}
