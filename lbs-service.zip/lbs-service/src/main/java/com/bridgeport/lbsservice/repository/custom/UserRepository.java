package com.bridgeport.lbsservice.repository.custom;

import com.bridgeport.lbsservice.dto.UserDTO;
import com.bridgeport.lbsservice.dto.request.UserRequest;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor
public class UserRepository {

    private static final RowMapper<UserDTO> userDTORowMapper = (rs, rowNum) -> UserDTO.builder()
            .id(rs.getLong("id"))
            .username(rs.getString("username"))
            .password(rs.getString("password"))
            .roleId(rs.getInt("role_id"))
            .firstName(rs.getString("first_name"))
            .middleName(rs.getString("middle_name"))
            .lastName(rs.getString("last_name"))
            .gender(rs.getString("gender"))
            .ssn(rs.getString("ssn"))
            .email(rs.getString("email"))
            .phone(rs.getString("phone"))
            .country(rs.getString("country"))
            .state(rs.getString("state"))
            .city(rs.getString("city"))
            .street(rs.getString("street"))
            .zip(rs.getString("zip"))
            .build();
    private PasswordEncoder passwordEncoder;
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void save(UserRequest userRequest) {
        String query = "INSERT INTO" +
                " user (username, password, first_name, middle_name, last_name, ssn, email, phone, zip, street, city, state, created_timestamp, role_id, country_id, gender_id)" +
                " VALUES (:username, :password, :firstName, :middleName, :lastName, :ssn, :email, :phone, :zip, :street, :city, :state, :createdTimestamp, :roleId, :countryId, :genderId)";
        Map<String, Object> params = new HashMap<>();
        params.put("username", userRequest.getUsername());
        params.put("password", passwordEncoder.encode(userRequest.getPassword()));
        params.put("firstName", userRequest.getFirstName());
        params.put("middleName", userRequest.getMiddleName());
        params.put("lastName", userRequest.getLastName());
        params.put("ssn", userRequest.getSsn());
        params.put("email", userRequest.getEmail());
        params.put("phone", userRequest.getPhone());
        params.put("zip", userRequest.getZip());
        params.put("street", userRequest.getStreet());
        params.put("city", userRequest.getCity());
        params.put("state", userRequest.getState());
        params.put("createdTimestamp", new Date());
        params.put("roleId", userRequest.getUserRole().ordinal());
        params.put("countryId", userRequest.getCountryId());
        params.put("genderId", userRequest.getGenderId());
        jdbcTemplate.update(query, params);
    }

    public UserDTO getByUsername(String username) {
        String query = "SELECT u.*, c.name AS country, g.name AS gender" +
                " FROM user u" +
                " LEFT JOIN country c ON c.id = u.country_id" +
                " LEFT JOIN gender g ON g.id = u.gender_id" +
                " WHERE u.username = :username";
        List<UserDTO> userDTOs = jdbcTemplate.query(query, Map.of("username", username), userDTORowMapper);
        return !userDTOs.isEmpty() ? userDTOs.get(0) : null;
    }

    public List<UserDTO> findAllExceptWithGivenUsername(String username) {
        String query = "SELECT u.*, c.name AS country, g.name AS gender" +
                " FROM user u" +
                " LEFT JOIN country c ON c.id = u.country_id" +
                " LEFT JOIN gender g ON g.id = u.gender_id" +
                " WHERE u.username <> :username" +
                " ORDER BY created_timestamp DESC";
        return jdbcTemplate.query(query, Map.of("username", username), userDTORowMapper);
    }
}
