package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.entity.Gender;
import com.bridgeport.lbsservice.repository.GenderRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
public class GenderController {

    private GenderRepository genderRepository;

    @GetMapping("/genders")
    public ResponseEntity<List<Gender>> getGenders() {
        return new ResponseEntity<>(genderRepository.getGenders(), HttpStatus.OK);
    }
}
