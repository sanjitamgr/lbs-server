package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.config.CredentialsProvider;
import com.bridgeport.lbsservice.dto.response.TransactionResponse;
import com.bridgeport.lbsservice.model.UserRole;
import com.bridgeport.lbsservice.repository.custom.TransactionRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
public class TransactionController {

    private CredentialsProvider credentialsProvider;
    private TransactionRepository transactionRepository;

    @PostMapping("/transaction/{bidId}")
    public ResponseEntity<Void> createTransaction(@PathVariable("bidId") Long bidId) {
        transactionRepository.save(bidId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/transactions")
    public ResponseEntity<List<TransactionResponse>> transactions() {
        List<TransactionResponse> transactionResponses = credentialsProvider.getUserRole() == UserRole.ADMIN
                ? transactionRepository.findAll()
                : transactionRepository.findBySellerOrBuyerId(credentialsProvider.getUserId());
        return new ResponseEntity<>(transactionResponses, HttpStatus.OK);
    }

    @GetMapping("/transactions/my")
    public ResponseEntity<List<TransactionResponse>> myTransactions() {
        List<TransactionResponse> transactionResponses = transactionRepository.findBySellerOrBuyerId(credentialsProvider.getUserId());
        return new ResponseEntity<>(transactionResponses, HttpStatus.OK);
    }
}
