package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.config.CredentialsProvider;
import com.bridgeport.lbsservice.dto.request.AuctionLaptopRequest;
import com.bridgeport.lbsservice.dto.response.AuctionLaptopResponse;
import com.bridgeport.lbsservice.repository.custom.AuctionLaptopRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class AuctionLaptopController {

    private CredentialsProvider credentialsProvider;
    private AuctionLaptopRepository auctionLaptopRepository;

    @PostMapping("/auction-laptop")
    public ResponseEntity<Void> createAuctionLaptop(@RequestBody AuctionLaptopRequest auctionLaptopRequest) {
        auctionLaptopRepository.save(auctionLaptopRequest, credentialsProvider.getUserId());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/auction-laptop/{id}")
    public ResponseEntity<AuctionLaptopResponse> auctionLaptopById(@PathVariable("id") Long id) {
        return new ResponseEntity<>(auctionLaptopRepository.findById(id), HttpStatus.OK);
    }

    @GetMapping("/auction-laptops")
    public ResponseEntity<List<AuctionLaptopResponse>> auctionLaptops() {
        List<AuctionLaptopResponse> auctionLaptopResponses = auctionLaptopRepository.findAllExceptSold();
        return new ResponseEntity<>(auctionLaptopResponses, HttpStatus.OK);
    }

    @GetMapping("/auction-laptops/my")
    public ResponseEntity<List<AuctionLaptopResponse>> myAuctionLaptops() {
        List<AuctionLaptopResponse> auctionLaptopResponses = auctionLaptopRepository.findAllForGivenUserId(credentialsProvider.getUserId());
        return new ResponseEntity<>(auctionLaptopResponses, HttpStatus.OK);
    }
}
