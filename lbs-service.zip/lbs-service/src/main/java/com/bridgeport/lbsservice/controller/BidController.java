package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.config.CredentialsProvider;
import com.bridgeport.lbsservice.dto.request.BidRequest;
import com.bridgeport.lbsservice.dto.response.BidResponse;
import com.bridgeport.lbsservice.repository.custom.BidRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
public class BidController {

    private CredentialsProvider credentialsProvider;
    private BidRepository bidRepository;

    @PostMapping("/bid")
    public ResponseEntity<Void> createBid(@RequestBody BidRequest bidRequest) {
        bidRepository.save(bidRequest, credentialsProvider.getUserId());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/bids/{auctionLaptopId}")
    public ResponseEntity<List<BidResponse>> bids(@PathVariable("auctionLaptopId") Long auctionLaptopId) {
        List<BidResponse> bidResponses = bidRepository.findAll(auctionLaptopId);
        return new ResponseEntity<>(bidResponses, HttpStatus.OK);
    }
}
