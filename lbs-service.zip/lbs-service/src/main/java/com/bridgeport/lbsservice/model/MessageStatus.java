package com.bridgeport.lbsservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum MessageStatus {

    UNSEEN("Unseen"), SEEN("Seen");

    @Getter
    private String label;
}
