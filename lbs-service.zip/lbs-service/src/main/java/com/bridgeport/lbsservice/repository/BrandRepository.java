package com.bridgeport.lbsservice.repository;

import com.bridgeport.lbsservice.entity.Brand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BrandRepository extends JpaRepository<Brand, Long> {

    @Query(value = "SELECT * FROM brand ORDER BY name ASC", nativeQuery = true)
    List<Brand> getBrands();
}
