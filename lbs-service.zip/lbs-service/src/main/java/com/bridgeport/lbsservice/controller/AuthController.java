package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.config.JwtTokenService;
import com.bridgeport.lbsservice.config.JwtUserDetailsService;
import com.bridgeport.lbsservice.dto.UserDTO;
import com.bridgeport.lbsservice.dto.request.LoginRequest;
import com.bridgeport.lbsservice.dto.response.LoginResponse;
import com.bridgeport.lbsservice.repository.custom.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
public class AuthController {

    private AuthenticationManager authenticationManager;
    private JwtTokenService jwtTokenService;
    private JwtUserDetailsService userDetailsService;
    private UserRepository userRepository;

    @PostMapping(value = "/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
        } catch (DisabledException e) {
            throw new Exception("User Disabled", e);
        } catch (BadCredentialsException e) {
            throw new Exception("Invalid Credentials", e);
        }
        final UserDTO userDTO = userRepository.getByUsername(loginRequest.getUsername());
        final String token = jwtTokenService.generateToken(userDTO);
        return ResponseEntity.ok(new LoginResponse(token));
    }
}
