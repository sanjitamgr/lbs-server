package com.bridgeport.lbsservice.controller;

import com.bridgeport.lbsservice.dto.response.UserRoleResponse;
import com.bridgeport.lbsservice.model.UserRole;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class UserRoleController {

    @GetMapping("/user-roles")
    public ResponseEntity<List<UserRoleResponse>> getUserRoles() {
        List<UserRoleResponse> userRoleResponses = Arrays.asList(UserRole.values()).stream()
                .map(ur -> new UserRoleResponse(ur.name(), ur.getLabel()))
                .toList();
        return new ResponseEntity<>(userRoleResponses, HttpStatus.OK);
    }
}
