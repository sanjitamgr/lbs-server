package com.bridgeport.lbsservice.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionResponse {

    private String title;
    private String seller;
    private String buyer;
    private String shippingTrackNumber;
    private BigDecimal initialPrice;
    private BigDecimal soldPrice;
    private Date date;
}
