package com.bridgeport.lbsservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum UserRole {

    USER("User"), ADMIN("Admin");

    @Getter
    private String label;
}
