package com.bridgeport.lbsservice.repository.custom;

import com.bridgeport.lbsservice.dto.response.DashboardResponse;
import com.bridgeport.lbsservice.model.AuctionStatus;
import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Map;

@Repository
@AllArgsConstructor
public class DashboardRepository {

    private NamedParameterJdbcTemplate jdbcTemplate;

    public DashboardResponse getDashboardResponse() {
        String userCountQuery = "SELECT COUNT(*) AS userCount FROM user";
        String itemCountQuery = "SELECT COUNT(*) AS itemCount FROM auction_laptop";
        String transactionCountQuery = "SELECT COUNT(*) AS transactionCount FROM auction_laptop WHERE status_id = :statusId";
        String transactionSumQuery = "SELECT SUM(b.price) AS transactionSum FROM transaction t LEFT JOIN bid b ON b.id = t.bid_id";
        Map<String, Object> userCountResult = jdbcTemplate.queryForMap(userCountQuery, Map.of());
        Map<String, Object> itemCountResult = jdbcTemplate.queryForMap(itemCountQuery, Map.of());
        Map<String, Object> transactionCountResult = jdbcTemplate.queryForMap(transactionCountQuery, Map.of("statusId", AuctionStatus.SOLD.ordinal()));
        Map<String, Object> transactionSumResult = jdbcTemplate.queryForMap(transactionSumQuery, Map.of());
        return DashboardResponse.builder()
                .totalUser((Long) userCountResult.get("userCount"))
                .totalItem((Long) itemCountResult.get("itemCount"))
                .totalTransaction((Long) transactionCountResult.get("transactionCount"))
                .totalTransactionAmt((BigDecimal) transactionSumResult.get("transactionSum"))
                .build();
    }
}
